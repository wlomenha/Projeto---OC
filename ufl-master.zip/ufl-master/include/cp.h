#ifndef _CP_H
#define _CP_H

#include "main.h"
#include "instance.h"

class CP{
public:
	CP(Instance& ins, IloEnv& env);
	~CP();

	Instance& ins;

	IloEnv& env;
	IloCplex cplex;
	IloModel model;
	IloModel primal;

	IloNumVarArray u;
	IloNumVar v;

	IloNumVar** primal_x;
	IloNumVarArray primal_y;

	double** x;
	double* y;

	double z;
	double run_time;

	void load_model();
	void solve();
	void print_solution();
	bool sub_problem();
	
};

#endif