#ifndef _BB_H
#define _BB_H

#include "main.h"
#include "instance.h"

class BB{
public:
	BB(const Instance& ins, IloEnv& env);
	~BB();

	const Instance& ins;
	IloEnv& env;
	IloCplex cplex;
	IloModel model;


	IloNumVar** x;
	IloNumVar* y;

	bool** fixed_x;
	bool* fixed_y;

	double z;
	IloAlgorithm::Status status;
	double run_time;


	void load_model();
	void solve();
	void print_solution();
};

#endif

