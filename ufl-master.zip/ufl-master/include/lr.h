#ifndef _LR_H
#define _LR_H


#include "main.h"
#include "instance.h"
#include "heuristic.h"

class Heuristic;

class LR{
public:
	LR(const Instance & ins);
	~LR();

	const Instance& ins;

	int max_iter;
	int improve_iter;
	double eps;

	double run_time;

	double** x;
	double* y;

	double* best_y;
	double ub;
	double lb;

	bool* fixed_y;
	bool** fixed_x;

	double* g;
	double* u;

	int lb_y;
	int ub_y;

	int* lb_x;
	int* ub_x;

	std::vector<std::pair<double, int>> C;


	void solve();
	double sub_problem();

	void fix_variables(double z);

	double get_ub();

	void set_primal();

	void set_primal(Heuristic& h);

	void print_solution();

	void letchford_fix();

	double dummy_heuristic();
	
};

#endif