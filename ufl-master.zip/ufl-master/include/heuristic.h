#ifndef _HEURISTIC_H
#define _HEURISTIC_H

#include "main.h"
#include "lr.h"
#include "instance.h"

class LR;


class Heuristic{
public:
	Heuristic(const Instance& ins);
	Heuristic(const Instance& ins, const LR& lr);
	~Heuristic();

	const Instance& ins;

	bool* fixed_y;
	bool** fixed_x;

	int** c;
	int* f;

	int lb_y;
	int ub_y;

	int* lb_x;
	int* ub_x;

	double** x;
	double* y;

	double ub;
	double lb;

	double run_time;

	double run();
	double construction();
	double local_search();

	double swap_cost(int a, int b);
	void swap_move(int a, int b);

	double add_cost(int a);
	void add_move(int a);

	double remove_cost(int a);
	void remove_move(int a);

	void update_fixes(bool* fixed_y, bool** fixed_x, int lb_y, int ub_y, int* lb_x,
		int* ub_x);

	double get_obj(double** x, double* y);
	
};

#endif