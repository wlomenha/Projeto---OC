#ifndef _MAIN_H
#define _MAIN_H

#include "param.h"
#include <chrono>
#include <boost/range/adaptor/reversed.hpp>


//Objeto global de parâmetros
extern Param g_params;

#endif