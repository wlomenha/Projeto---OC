#ifndef _PARAM_H
#define _PARAM_H

#include "boost/program_options.hpp"
#include <fstream>
#include <iostream>
#include <ilcplex/ilocplex.h>

class Param{
public:
	Param();
	Param(const Param& p);
	Param(boost::program_options::variables_map vm);

	std::string instance;
	std::string method;
	std::string output;

	std::ofstream result_file;
	
	double EPS, time_limit;

	int bb_node_limit, lr_max_iter, h_max_iter;

	bool debug, bb_cplex_buffs, show_solution;

	Param& operator=(const Param& p);
	friend std::ostream& operator<<(std::ostream& out, const Param &s);
	~Param();
	
};

#endif