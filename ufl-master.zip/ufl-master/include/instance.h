#ifndef _INSTANCE_H
#define _INSTANCE_H

#include "main.h"

class Instance{
public:
	Instance(std::string path);
	~Instance();

	std::string path;

	int m,n;
	int** c;
	int* f;


	friend std::ostream& operator<<(std::ostream& out, const Instance &ins);
	
};

#endif