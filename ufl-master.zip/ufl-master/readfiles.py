import numpy as np
import os
import math 
import matplotlib.pyplot as plt
from scipy.spatial import distance
import sys

def readFiles(n, size="small"):
    # Parameters
    a = 0 # upper bound
    b = 1 # lower bound

    # Random coordinates 
    yPoint = np.random.random_sample((n,)) # generate random y
    xPoint = np.random.random_sample((n,))  # generate random x

    # Create limits
    plt.xlim((b,a))
    plt.ylim((b,a))

    # Plot points
    # for i in range(n):
    #     plt.plot(xPoint[i],yPoint[i],'ro')
    # # plt.show()

    dim = (n,n)
    matrix = np.zeros(dim)

    for i in range(0, n):
        for j in range(0, n):
            a = (xPoint[i], yPoint[i])
            b = (xPoint[j], yPoint[j])
            dist = distance.euclidean(a, b)
            matrix[i,j] = round(dist*5000)
        

    facilityCosts = np.zeros(n, dtype=int)

    textFile = size
    if textFile == "small":
        facilityCosts.fill(round((math.sqrt(n)/1000)*5000))
    elif textFile == "medium":
        facilityCosts.fill(round((math.sqrt(n)/100)*5000))
    elif textFile == "large":
        facilityCosts.fill(round((math.sqrt(n)/10)*5000))

    
    with open(os.path.join(os.getcwd(), 'instances', 'han_{}_{}.txt'.format(n, textFile)),'w') as f:
        f.write('{}'.format(n)+' '+ '{}'.format(n)+'\n')
        f.write(" ".join(map(str, facilityCosts)) + '\n') 
        np.savetxt(f,matrix, fmt='%i')


rng1 = np.linspace(250,1750, 7, dtype=int)
rng2 = np.linspace(500, 4000, 8, dtype=int)
rng3 = np.linspace(1000, 10000, 10, dtype=int)


# for i in rng1:
#     readFiles(i)

readFiles(int(sys.argv[1]), sys.argv[2])

