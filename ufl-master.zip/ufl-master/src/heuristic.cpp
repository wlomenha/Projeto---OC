#include "../include/heuristic.h"


Heuristic::Heuristic(const Instance& ins): ins(ins), lb_y(1), ub_y(ins.m), ub(IloInfinity),
	lb(-IloInfinity){
	fixed_x = new bool*[ins.m];
	fixed_y = new bool[ins.m];
	x = new double*[ins.m];
	y = new double[ins.m];
	lb_x = new int[ins.m];
	ub_x = new int[ins.m];

	c = ins.c;
	f = ins.f;

	lb_y = 1;
	ub_y = ins.m;

	for(int i = 0; i < ins.m; ++i){
		fixed_y[i] = false;
		y[i] = 0;
		lb_x[i] = 1;
		ub_x[i] = ins.n;
		fixed_x[i] = new bool[ins.n];
		x[i] = new double[ins.n];
		for(int j = 0; j < ins.n; ++j){
			fixed_x[i][j] = false;
			x[i][j] = 0;
		}
	}
}

Heuristic::Heuristic(const Instance& ins, const LR& lr): ins(ins), lb_y(lr.lb_y), ub_y(lr.ub_y),
	ub(lr.ub), lb(lr.lb){
	fixed_x = new bool*[ins.m];
	fixed_y = new bool[ins.m];
	x = new double*[ins.m];
	y = new double[ins.m];
	lb_x = new int[ins.m];
	ub_x = new int[ins.m];

	c = ins.c;
	f = ins.f;

	for(int i = 0; i < ins.m; ++i){
		fixed_y[i] = lr.fixed_y[i];
		y[i] = lr.y[i];
		lb_x[i] = lr.lb_x[i];
		ub_x[i] = lr.ub_x[i];
		fixed_x[i] = new bool[ins.n];
		x[i] = new double[ins.n];
		for(int j = 0; j < ins.n; ++j){
			fixed_x[i][j] = false;
			x[i][j] = lr.x[i][j];
		}
	}
}

double Heuristic::run(){
	std::chrono::high_resolution_clock::time_point t0 = 
		std::chrono::high_resolution_clock::now();

	for(int k = 0; k < g_params.h_max_iter; ++k){
		ub = construction();
		ub = local_search();
	}


	std::chrono::high_resolution_clock::time_point dt = 
		std::chrono::high_resolution_clock::now();
	run_time = std::chrono::duration_cast<std::chrono::nanoseconds>
			(dt - t0).count() / pow(10,9);
	return ub;
}

double Heuristic::construction(){
	std::set<int> open;
	std::set<int> closed;
	bool improve,infeasible;

	ub = 0;
	for(int i = 0; i < ins.m; ++i){
		closed.insert(i);
		y[i] = 0;
		for(int j = 0 ; j < ins.n; ++j){
			x[i][j] = 0;
		}
	}

	std::vector<int> R(ins.m);
	int z = INT_MAX;
	int iter = 0;
	do{
		for(int i = 0; i < ins.m; ++i){
			R[i] = 0;
		}
		improve = false;
		for(auto i: closed){
			if(open.size() == 0){
				R[i] = -f[i];
			}else{
				int omega = 0;
				for(int j = 0; j < ins.n; ++j){
					int min_kval = INT_MAX;
					for(auto k: open){
						if(c[k][j] - c[i][j] < min_kval){
							min_kval = c[k][j] - c[i][j];
						}
					}

					if(min_kval > 0 && min_kval < INT_MAX){
						omega += min_kval;
					}
				}
				if(fixed_y[i]){
					R[i] = -f[i];
				}else{
					R[i] = omega - f[i];
				}
			}
		}

		int max_i = -1;
		int max_rval = -INT_MAX;

		for(auto i: closed){
			if(R[i] > max_rval && !fixed_y[i]){
				max_rval = R[i];
				max_i = i;
			}
		}

		if(max_i != -1){
			open.insert(max_i);
			closed.erase(max_i);
			y[max_i] = 1;
		}

		std::vector<std::pair<int,int>> diffs;
		for(int j = 0; j < ins.n; ++j){
			int first = INT_MAX;
			int second = INT_MAX;
			for(auto i: open){
				if(c[i][j] < first){
					second = first;
					first = c[i][j];
				}else if(c[i][j] < second){
					second = c[i][j];
				}
			}

			if(open.size() == 1)
				diffs.push_back(std::make_pair(-first,j));	
			else
				diffs.push_back(std::make_pair(first-second,j));	
		}

		std::sort(diffs.begin(),diffs.end(), std::greater<std::pair<int,int>>());
		infeasible = false;
		for(auto diff: diffs){
			int j = diff.second;
			int min_cost = INT_MAX;
			int min_i = -1;
			for(auto i: open){
				if(c[i][j] < min_cost){
					min_cost = c[i][j];
					min_i = i;
				}
			}

			if(min_i != -1){
				for(auto i: open){
					if(x[i][j] == 1){
						x[i][j] = 0;
					}
				}
				x[min_i][j] = 1;
			}else{
				infeasible = true;
				break;
			}
		}

		if(!infeasible){
			std::set<int> aux_close;
			for(auto i: open){
				if(y[i] == 1){
					bool has_client = false;
					for(int j = 0; j < ins.n; ++j){
						if(x[i][j] == 1){
							has_client = true;
							break;
						}
					}

					if(!has_client){
						y[i] = 0;
						aux_close.insert(i);
						closed.insert(i);
					}
				}
			}
			for(auto i: aux_close){
				open.erase(i);
			}

			ub = 0;
			for(int i = 0; i < ins.n; ++i){
				if(y[i] == 1){
					ub += f[i];
					for(int j = 0; j < ins.n; ++j){
						if(x[i][j] == 1){
							ub += c[i][j];
						}
					}
				}
			}

			if(ub < z){
				z = ub;
				improve = true;
			}
		}
		std::cout << "ITER UB" << iter++ << " " << ub << "\n";
	}while(improve || infeasible);
	return ub;
}


double Heuristic::local_search(){
	std::set<int> open;
	std::set<int> closed;
	bool improve = false;
	int iter = 0;
	do{
		improve = false;
		for(int i = 0; i < ins.m; ++i){
			if(y[i] == 1){
				open.insert(i);
			}else{
				closed.insert(i);
			}
		}

		std::pair<int,int> move;
		int best_cost = 0;
		for(auto a: open){
			int cost = remove_cost(a);
			if(cost < best_cost){
				improve = true;
				move = std::make_pair(a, -1);
				best_cost = cost;
			}
		}

		if(improve){
			remove_move(move.first);
		}else{
			for(auto a: open){
				for(auto b: closed){
					if(!fixed_y[b]){
						int cost = swap_cost(a,b);
						if(cost < best_cost){
							improve = true;
							move = std::make_pair(a,b);
							best_cost = cost;
						}
					}
				}
			}
			if(improve){
				swap_move(move.first, move.second);
			}else{
				for(auto a: closed){
					if(!fixed_y[a]){
						int cost = add_cost(a);
						if(cost < best_cost){
							improve = true;
							move = std::make_pair(a,-1);
							best_cost = cost;
						}
					}
				}
				if(improve){
					add_move(move.first);
				}
			}
		}
		if(ub == lb){
			break;
		}
		open.clear();
		closed.clear();
		std::cout << "iter UB " << iter++ << " " << ub << "\n";
	}while(improve);

	return ub;
}


double Heuristic::add_cost(int a){
	if(!fixed_y[a]){
		int cost = f[a];
		for(int j = 0; j < ins.n; ++j){
			for(int i = 0; i < ins.n; ++i){
				if(i != a && !fixed_x[a][j] && x[i][j] == 1 && c[i][j] > c[a][j]){
					cost -= c[i][j];
					cost += c[a][j];
				}
			}
		}
		return cost;
	}else{
		return INT_MAX;
	}
}

void Heuristic::add_move(int a){
	ub += f[a];
	y[a] = 1;
	for(int j = 0; j < ins.n; ++j){
		for(int i = 0; i < ins.n; ++i){
			if(i != a && !fixed_x[a][j] && x[i][j] == 1 && c[i][j] > c[a][j]){
				ub -= c[i][j];
				x[i][j] = 0;
				ub += c[a][j];
				x[a][j] = 1;
			}
		}
	}
}

double Heuristic::swap_cost(int a, int b){
	if(fixed_y[b])
		return INT_MAX;

	int cost = f[b]-f[a];
	std::set<int> released;
	for(int j = 0; j < ins.n; ++j){
		if(x[a][j] == 1){
			released.insert(j);
			cost -= c[a][j];
		}
	}

	for(auto it = released.begin(); it != released.end(); ++it){
		int j = *it;
		int min_cost = INT_MAX;
		for(int i = 0; i < ins.n; ++i){
			if(i != a && (y[i] == 1 || i == b) && !fixed_x[i][j] && c[i][j] < min_cost){
				min_cost = c[i][j];
			}
		}
		if(min_cost != INT_MAX)
			cost += min_cost;
		else
			return INT_MAX;
	}

	return cost;
}

void Heuristic::swap_move(int a, int b){
	std::set<int> released;
	ub += f[b]-f[a];
	
	for(int j = 0; j < ins.n; ++j){
		if(x[a][j] == 1){
			x[a][j] = 0;
			released.insert(j);
			ub -= c[a][j];
		}
	}
	y[a] = 0;
	y[b] = 1;

	for(auto it = released.begin(); it != released.end(); ++it){
		int j = *it;
		int min_cost = INT_MAX;
		int min_i = -1;
		for(int i = 0; i < ins.n; ++i){
			if(y[i] == 1 && !fixed_x[i][j] && c[i][j] < min_cost){
				min_cost = c[i][j];
				min_i = i;
			}
		}
		if(min_i != -1){
			ub += min_cost;
			x[min_i][j] = 1;
		}else{
			std::cout << "ERRO: Solução inviável ao tentar swap " << a << " " << b << "\n";
			exit(1);
		}
	}
}

double Heuristic::remove_cost(int a){
	int cost = -f[a];
	std::set<int> released;
	for(int j = 0; j < ins.n; ++j){
		if(x[a][j] == 1){
			cost -= c[a][j];
			released.insert(j);
		}
	}

	for(auto it = released.begin(); it != released.end(); ++it){
		int j = *it;
		int min_cost = INT_MAX;
		for(int i = 0; i < ins.n; ++i){
			if(i != a && !fixed_x[i][j] && y[i] == 1 && c[i][j] < min_cost){
				min_cost = c[i][j];
			}
		}

		if(min_cost != INT_MAX)
			cost += min_cost;
		else
			return INT_MAX;
	}

	return cost;
}

void Heuristic::remove_move(int a){
	ub -= f[a];
	y[a] = 0;
	std::set<int> released;
	
	for(int j = 0; j < ins.n; ++j){
		if(x[a][j] == 1){
			ub -= c[a][j];
			x[a][j] = 0;
			released.insert(j);
		}
	}

	for(auto it = released.begin(); it != released.end(); ++it){
		int j = *it;
		int min_cost = INT_MAX;
		int min_i = -1;

		for(int i = 0; i < ins.n; ++i){
			if(y[i] == 1 && !fixed_x[i][j] && c[i][j] < min_cost){
				min_cost = c[i][j];
				min_i = i;
			}
		}

		if(min_i != -1){
			ub += min_cost;
			x[min_i][j] = 1;
		}else{
			std::cout << "ERRO: Solução inviável ao tentar remove " << a << "\n";
			exit(1);
		}
	}
}


double Heuristic::get_obj(double** x, double* y){
	double obj_val = 0;
	for(int i = 0; i < ins.m; ++i){
		obj_val += f[i]*y[i];
		for(int j = 0; j < ins.n; ++j){
			obj_val += c[i][j]*x[i][j];
		}
	}
	return obj_val;
}

Heuristic::~Heuristic(){

	for(int i = 0; i < ins.m; ++i){
		delete[] x[i];
		delete[] fixed_x[i];
	}

	delete[] x; delete[] y;
	delete[] fixed_x; delete[] fixed_y;
	delete[] lb_x; delete[] ub_x;
}