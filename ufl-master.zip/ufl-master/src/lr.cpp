#include "../include/lr.h"


LR::LR(const Instance& ins): ins(ins), max_iter(g_params.lr_max_iter), 
	improve_iter(max_iter/30), eps(2), lb_y(1), ub_y(ins.m), lb(-IloInfinity), 
	ub(IloInfinity){

	x = new double*[ins.m];
	y = new double[ins.m];
	fixed_x = new bool*[ins.m];
	best_y = new double[ins.m];
	for(int i = 0; i < ins.m; ++i){
		y[i] = 0;
		best_y[i] = 0;
		x[i] = new double[ins.n];
		fixed_x[i] = new bool[ins.n];
		for(int j = 0; j < ins.n; ++j){
			x[i][j] = 0;
		}
	}
	fixed_y = new bool[ins.m];

	for(int i = 0; i < ins.m; ++i){
		fixed_y[i] = false;
		for(int j = 0; j < ins.n; ++j){
			fixed_x[i][j] = false;
		}
	}

	g = new double[ins.n];
	u = new double[ins.n];
	for(int i = 0; i < ins.n; ++i){
		g[i] = 0;
		u[i] = 0;
	}

	lb_x = new int[ins.m];
	ub_x = new int[ins.m];

	for(int i = 0; i < ins.m; ++i){
		lb_x[i] = 1;
		ub_x[i] = ins.n;
	}
}

void LR::solve(){
	std::chrono::high_resolution_clock::time_point t0 = 
		std::chrono::high_resolution_clock::now();
	double z, primal_obj, norm, mi;
	int k = 0;
	int no_improve = 0;
	bool improve_lb, improve_ub;
	bool updated_ub = false;

	letchford_fix();

	Heuristic h(ins,*this);
	ub = h.construction();
	std::cout << "CABOU CONTRUCAO\n";
	ub = h.local_search();
	std::cout << "CABOU LOCAL\n";
	set_primal(h);


	for(int k = 0; k < max_iter; ++k){
		z = sub_problem();
		primal_obj = get_ub();

		improve_ub = improve_lb = false;

		if(z > lb-g_params.EPS && z < ub+g_params.EPS){
			lb = z;
			improve_lb = true;
			no_improve = 0;
		}else if(z > ub-g_params.EPS){
			lb = z;
			std::cout << "ERRO: INVIABILIDADE NA RL. RESULTADO DO SUBPROBLEMA\n";
			std::cout << "z = " << z << ", lb =  " << lb << ", ub =  " << ub << "\n";
			//função debug?
			exit(1);
		}else{
			++no_improve;
		}

		if(primal_obj < ub-g_params.EPS){
			ub = primal_obj;
			improve_ub = true;
			updated_ub = true;
			for(int i = 0; i < ins.m; ++i)
				best_y[i] = y[i];
		}

		if(no_improve >= improve_iter){
			no_improve = 0;
			eps *= 0.5;
			if(eps < g_params.EPS){
				std::cout << "SAIU EPS\n";
				break;
			}
		}

		norm = 0;
		for(int j = 0; j < ins.n; ++j){
			g[j] = 1;
			for(int i = 0; i < ins.m; ++i){
				if(!fixed_x[i][j])
					g[j] -= x[i][j];
			}
			norm += g[j]*g[j];
		}

		if(ub-z < 1-g_params.EPS){
			std::cout << "SAIU GAP\n";
			break;
		}
		mi = eps*((1.02*ub-z)/norm);
		if(improve_ub || improve_lb)
			fix_variables(z);
	
		for(int j = 0; j < ins.n; ++j){
			u[j] = u[j]+mi*g[j];
			// u[j] = fmax(0, u[j]+mi*g[j]);
		}
		std::chrono::high_resolution_clock::time_point t = 
			std::chrono::high_resolution_clock::now();
		double elapsed_time = std::chrono::duration_cast<std::chrono::nanoseconds>
					(t - t0).count() / pow(10,9);
		if(elapsed_time > g_params.time_limit){
			std::cout << "SAIU TEMPO\n";
			break;
		}

		std::cout << "Iter LB UB " << k << " " << lb << " " << ub << "\n";
	}

	if(updated_ub){
		set_primal();
	}
	int count_y = 0;
	int count_x = 0;
	for(int i = 0; i < ins.m; ++i){
		if(fixed_y[i]){
			++count_y;
		}
		for(int j = 0; j < ins.n; ++j){
			if(fixed_x[i][j])
				++count_x;
		}
	}
	std::cout << "Fixações Y: " << count_y << "\n";
	std::cout << "Fixações X: " << count_x << "\n";

	std::chrono::high_resolution_clock::time_point dt = 
		std::chrono::high_resolution_clock::now();
	run_time = std::chrono::duration_cast<std::chrono::nanoseconds>
				(dt - t0).count() / pow(10,9);
}

double LR::sub_problem(){
	double z = 0;
	C.clear();
	for(int i = 0; i < ins.m; ++i){
		y[i] = 0;
		for(int j = 0; j < ins.n; ++j){
			x[i][j] = 0;
		}
	}

	for(int j = 0; j < ins.n; ++j)
		z += u[j];

	std::vector<std::vector<int>> selected(ins.m, std::vector<int>());
	for(int i = 0; i < ins.m; ++i){
		if(!fixed_y[i]){
			std::vector<std::pair<double,int>> clients;
			for(int j = 0; j < ins.n; ++j){
				if(!fixed_x[i][j]){
					clients.push_back(std::make_pair(ins.c[i][j]-u[j],j));
				}
			}

			std::sort(clients.begin(), clients.end());
			double sum = 0;
			if(clients.size() >= lb_x[i]){
				for(int k = 0; k < lb_x[i]; ++k){
					sum += clients[k].first;
					selected[i].push_back(clients[k].second);
				}
				int k = lb_x[i];
				while(k < clients.size() && clients[k].first < -g_params.EPS &&
					k < ub_x[i]){
					sum += clients[k].first;
					selected[i].push_back(clients[k].second);
					++k;
				}
			}else{
				std::cout << "ERRO. INVIABILIDADE NA RL. ERRO NO LB DE CLIENTES\n";
				exit(1);
			}
			C.push_back(std::make_pair(ins.f[i]+sum, i));
		}else{
			C.push_back(std::make_pair(IloInfinity,i));
		}
	}

	std::sort(C.begin(), C.end());

	if(lb_y > ub_y){
		std::cout << "ERRO. INVIABILIDADE NA RL. ERRO NO LB DAS FACILITIES\n";
		exit(1);
	}

	int k = 0;
	for(k = 0; k < lb_y; ++k){
		y[C[k].second] = 1;
		z += C[k].first;
	}

	while(k < C.size() && C[k].first < -g_params.EPS && k < ub_y){
		y[C[k].second] = 1;
		z += C[k].first;
		++k;
	}


	for(int i = 0; i < ins.m; ++i){
		if(!fixed_y[i]  && 1-y[i] < g_params.EPS){
			for(auto j: selected[i]){
				x[i][j] = 1;
			}

		}
	}
	return z;
}


void LR::letchford_fix(){

	for(int j = 0; j < ins.n; ++j){
		double min_val = IloInfinity;
		for(int i = 0; i < ins.m; ++i){
			if(!fixed_y[i] && !fixed_x[i][j] && ins.c[i][j]+ins.f[i] < min_val){
				min_val = ins.c[i][j]+ins.f[i];
			}
		}
		double delta = min_val;
		for(int i = 0; i < ins.m; ++i){
			if(!fixed_x[i][j] && ins.c[i][j] > delta-g_params.EPS){
				fixed_x[i][j] = true;
			}
		}
	}


	for(int j = 0; j < ins.n; ++j){
		for(int i = 0; i < ins.m; ++i){
			if(!fixed_x[i][j]){

				std::set<int> I_star;
				for(int p = 0; p < ins.m; ++p){
					if(fixed_x[i][j] || ins.c[p][j] >= ins.c[i][j]){
						I_star.insert(p);
					}
				}

				std::vector<double> c_ij(ins.n,0);
				for(int q = 0; q < ins.n; ++q){
					double min_val = IloInfinity;
					for(int p = 0; p < ins.m; ++p){
						if(!fixed_x[p][q] && ins.c[p][q] < min_val &&
							I_star.find(p) != I_star.end()){
							min_val = ins.c[p][q];
						}
					}
					c_ij[q] = min_val;
				}

				for(int p = 0; p < ins.m; ++p){
					if(I_star.find(p) == I_star.end()){
						double sum = 0;
						for(int q = 0; q < ins.n; ++q){
							if(!fixed_x[p][q]){
								if (c_ij[q] == IloInfinity){
									sum = IloInfinity;
									break;
								}else if(c_ij[q]-ins.c[p][q] > g_params.EPS){
									sum += c_ij[q]-ins.c[p][q];
								}
							}

						}

						if(ins.f[p] < sum-g_params.EPS){
							for(auto k: I_star){
								if(!fixed_x[k][j]){
									fixed_x[k][j] = true;
								}
							}
						}
					}
				}
			}
		}
	}

	for(int i = 0; i < ins.m; ++i){
		if(!fixed_y[i]){
			bool has_client = false;
			for(int j = 0; j < ins.n; ++j){
				if(!fixed_x[i][j])
					has_client = true;
			}

			if(!has_client){
				fixed_y[i] = true;
			}
		}
	}

}

void LR::fix_variables(double z){
	std::vector<std::pair<double,int>> closed;
	std::vector<std::pair<double,int>> open;

	int* min_i = new int[ins.n];
	for(int j = 0; j < ins.n; ++j){
		double min_val = IloInfinity;
		int min_ind = -1;
		for(int i = 0; i < ins.m; ++i){
			if(!fixed_y[i] && !fixed_x[i][j] && ins.c[i][j] < min_val){
				min_val = ins.c[i][j];
				min_ind = i;
			}
		}

		min_i[j] = min_ind;
	}

	for(auto& elem: C){
		if(1-y[elem.second] < g_params.EPS){
			open.push_back(elem);
		}else{
			closed.push_back(elem);
		}
	}

	// Facility em 0
	if(open.size() < ub_y){
		for(auto& elem: boost::adaptors::reverse(closed)){
			int i = elem.second;
			if(!fixed_y[i]){
				double red_cost = z + elem.first;

				if(red_cost > ub+g_params.EPS){
					fixed_y[i] = true;
					lb_x[i] = ub_x[i] = 0;
					for(int j = 0; j < ins.n; ++j){
						if(!fixed_x[i][j]){
							fixed_x[i][j] = true;
						}
					}
				}else{
					break;
				}
			}
		}
	}

	// Facility em 1
	if(open.size() > 1){
		for(auto& elem: open){
			int i = elem.second;
			double red_cost = z - elem.first;

			if(red_cost > ub+g_params.EPS && open.size() > lb_y){
				for(int j = 0; j < ins.n; ++j){
					if(min_i[j] == i){
						for(int k = 0; k < ins.m; ++k){
							if(k != i && !fixed_x[k][j]){
								fixed_x[k][j] = true;
							}
						}	
					}
				}
			}else{
				break;
			}
		}
	}
	// Arco em zero para facility fechada
	for(auto& elem: closed){
		int i = elem.second;
		for(int j = 0; j < ins.n; ++j){
			//y[j] < g_params.EPS pode dar pau em instâncias onde c[i][i] != 0 
			if(open.size() < ub_y && !fixed_x[i][j] && y[j] < g_params.EPS &&
				ins.c[i][j]-u[j] > g_params.EPS &&
				z + elem.first + ins.c[i][j]-u[j] > ub+g_params.EPS){
				fixed_x[i][j] = true;
			}
		}
	}

	if(lb_y < ub_y){
		double cost = 0;
		if(open.size() > lb_y){
			for(int ind = open.size()-1; ind >= 0; --ind){
				cost += open[ind].first;
				if(z - cost > ub + g_params.EPS){
					if(ind+1 > lb_y){
						lb_y = ind+1;
					}
					break;
				}
			}
		}

		if(open.size() < ub_y){
			cost = 0;
			for(int ind = 0; ind < closed.size(); ++ind){
				cost += closed[ind].first;
				if(z + cost > ub + g_params.EPS){
					if(open.size()+ind < ub_y){
						ub_y = open.size() + ind;
					}
					break;
				}
			}
		}
	}


	for(auto& elem: open){
		int i = elem.second;

		std::vector<std::pair<double,int>> client_costs;
		std::vector<std::pair<double,int>> open_cli;
		std::vector<std::pair<double,int>> closed_cli;

		for(int j = 0; j < ins.n; ++j){
			client_costs.push_back(std::make_pair(ins.c[i][j]- u[j], j));
		}
		std::sort(client_costs.begin(), client_costs.end());

		for(auto& elem: client_costs){
			int j = elem.second;
			if(1-x[i][j] < g_params.EPS){
				open_cli.push_back(elem);
			}else{
				closed_cli.push_back(elem);
			}
		}

		for(int j = 0; j < ins.n; ++j){
			if(!fixed_x[i][j] && ins.c[i][j]-u[j] > g_params.EPS &&
				z + ins.c[i][j]-u[j] > ub+g_params.EPS && open_cli.size() > lb_x[i]){
				fixed_x[i][j] = true;
			}
		}

		if(lb_x[i] < ub_x[i]){
			double cost = 0;
			if(open_cli.size() > lb_x[i]){
				std::sort(open_cli.begin(), open_cli.end());
				for(int ind = open_cli.size()-1; ind >= 0; --ind){
					cost += open_cli[ind].first;
					if(z - cost > ub+g_params.EPS){
						if(ind+1 > lb_x[i]){
							lb_x[i] = ind+1;
						}
					}
				}
			}

			if(open_cli.size() < ub_x[i]){
				std::sort(closed_cli.begin(), closed_cli.end());
				cost = 0;
				for(int ind = 0; ind < closed_cli.size(); ++ind){
					cost += closed_cli[ind].first;
					if(z + cost > ub+g_params.EPS){
						if(open_cli.size()+ind < ub_x[i]){
							ub_x[i] = open_cli.size()+ind;
						}
					}
				}
			}
		}
	}
	delete[] min_i;

	for(int i = 0; i < ins.m; ++i){
		if(!fixed_y[i]){
			bool has_client = false;
			for(int j = 0; j < ins.n; ++j){
				if(!fixed_x[i][j])
					has_client = true;
			}

			if(!has_client){
				fixed_y[i] = true;
			}
		}
	}
}

double LR::get_ub(){
	double z = 0;
	for(int i = 0; i < ins.m; ++i){
		if(!fixed_y[i] && 1-y[i] < g_params.EPS){
			z += ins.f[i];
		}
	}

	for(int j = 0; j < ins.n; ++j){
		double min_val = IloInfinity;
		int min_i = -1;
		for(int i = 0; i < ins.m; ++i){
			if(!fixed_y[i] && 1-y[i] < g_params.EPS && !fixed_x[i][j] 
				&& ins.c[i][j] < min_val){
				min_val = ins.c[i][j];
				min_i = i;
			}
		}
		if(min_i != -1){
			z += min_val;
		}else{
			return IloInfinity;
		}
	}
	return z;
}

void LR::set_primal(){
	for(int i = 0; i < ins.m; ++i){
		y[i] = best_y[i];
		for(int j = 0; j < ins.n; ++j){
			x[i][j] = 0;
		}
	}

	for(int j = 0; j < ins.n; ++j){
		double min_val = IloInfinity;
		int min_i = -1;
		for(int i = 0; i < ins.m; ++i){
			if(!fixed_y[i] && 1-y[i] < g_params.EPS && !fixed_x[i][j] 
				&& ins.c[i][j] < min_val){
				min_val = ins.c[i][j];
				min_i = i;
			}
		}
		if(min_i != -1){
			x[min_i][j] = 1;
		}else{
			std::cout << "ERRO. INVIABILIDADE NA RL. SOLUÇÃO PRIMAL INVIÁVEL\n";
			exit(1);
		}
	}

}

void LR::set_primal(Heuristic& h){
	for(int i = 0; i < ins.m; ++i){
		y[i] = h.y[i];
		for(int j = 0; j < ins.n; ++j){
			x[i][j] = h.x[i][j];
		}
	}
}

void LR::print_solution(){
	std::stringstream out, solution;
	std::string status;
	if(lb < ub-g_params.EPS){
		status = "Feasible";
	}else if(lb > ub+g_params.EPS){
		status = "Infeasible";
	}else{
		status = "Optimal";
	}

	if(g_params.time_limit < IloInfinity)
		out << "Limite de tempo:\t" << g_params.time_limit << "\n";

	out << "Status: " << status << "\n";
	out << "LB: " << lb << "\n";
	out << "UB: " << ub << "\n";
	out << "Tempo(s): " << run_time << "\n";

	if(status == "Optimal" || status == "Feasible"){
		for(int i = 0; i < ins.m; ++i){
			if(!fixed_y[i] && 1-y[i] < g_params.EPS){
				solution << "\t" << i << ": ";
				for(int j = 0; j < ins.n; ++j){
					if(!fixed_x[i][j] && 1-x[i][j] < g_params.EPS){
						solution << j << " ";
					}
				}
				solution << "\n";
			} 
		}
	}

	if(g_params.debug){
		std::cout << out.str();
		if(g_params.show_solution)
			std::cout << solution.str();
	}else{
		g_params.result_file << out.str() << solution.str();
	}
}


double LR::dummy_heuristic(){
	double z  = 0;
	double min_val = IloInfinity;
	int min_i = -1;
	for(int i = 0; i < ins.n; ++i){
		if(!fixed_y[i] && ins.f[i] < min_val){
			min_val = ins.f[i];
			min_i = i;
		}
	}

	if(min_i == -1){
		std::cout << "ERRO. INVIABILIDADE NA RL. TODAS AS FACILITIES ESTAO FIXADAS\n";
		exit(1);
	}
	z = min_val;
	y[min_i] = 1;

	for(int j = 0; j < ins.n; ++j){
		z += ins.c[min_i][j];
		x[min_i][j] = 1;
	}

	return z;
}

LR::~LR(){
	for(int i = 0; i < ins.n; ++i){
		delete[] x[i]; delete[] fixed_x[i];
	}

	delete[] g; delete[] u; delete[] x; delete[] y;
	delete[] fixed_x; delete[] best_y;
	delete[] fixed_y; delete[] lb_x; delete[] ub_x;
}