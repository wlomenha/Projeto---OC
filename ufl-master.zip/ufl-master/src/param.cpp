#include "../include/param.h"

Param::Param(){}

Param::Param(const Param &p): 
	instance(p.instance),
	EPS(p.EPS),
	debug(p.debug),
	method(p.method),
	output(p.output),
	result_file(p.output, std::ios::out),
	bb_node_limit(p.bb_node_limit),
	bb_cplex_buffs(p.bb_cplex_buffs),
	time_limit(p.time_limit),
	show_solution(p.show_solution),
	lr_max_iter(p.lr_max_iter),
	h_max_iter(p.h_max_iter){
}

Param::Param(boost::program_options::variables_map vm): 
	instance{vm["instance"].as<std::string>()},
	EPS{vm["EPS"].as<double>()},
	debug{vm["debug"].as<bool>()},
	method{vm["method"].as<std::string>()},
	output{vm["output"].as<std::string>()},
	result_file(output, std::ios::out),
	bb_node_limit{vm["bb_node_limit"].as<int>()},
	bb_cplex_buffs{vm["bb_cplex_buffs"].as<bool>()},
	time_limit{vm["time_limit"].as<double>()},
	show_solution{vm["show_solution"].as<bool>()},
	lr_max_iter{vm["lr_max_iter"].as<int>()},
	h_max_iter{vm["h_max_iter"].as<int>()}{

	if(debug)
		std::cout << *this;	
}

Param& Param::operator=(const Param& p){
	if(this == &p)
		return *this;

	instance = p.instance;
	EPS = p.EPS;
	method = p.method;
	debug = p.debug;
	output = p.output;
	result_file = std::ofstream(p.output, std::ios::out);
	bb_cplex_buffs = p.bb_cplex_buffs;
	bb_node_limit = p.bb_node_limit;
	time_limit = p.time_limit;
	show_solution = p.show_solution;
	lr_max_iter = p.lr_max_iter;
	h_max_iter = p.h_max_iter;
	return *this;
}

std::ostream& operator<<(std::ostream& out, const Param &s){
	out << "Parâmetros:\n";
	if(s.debug)
		out << "Modo debug\n";
	out << "Instância: " << s.instance << "\n";
	out << "EPS: " << s.EPS << "\n";
	out << "Algoritmo: " << s.method << "\n";
	out << "Arquivo de saída: " << s.output << "\n";
	if(s.time_limit < IloInfinity)
		out << "Limite de Tempo: " << s.time_limit << "\n";
	if(s.show_solution)
		out << "Imprimindo solução\n";
	if(s.method == "bb" && s.bb_node_limit < INT_MAX)
		out << "Limite de Nós: " << s.bb_node_limit << "\n";
	if(s.method == "bb" && s.bb_cplex_buffs)
		out << "AJUDAS DO CPLEX ATIVADAS!!!\n";
	if(s.method == "lr" && s.lr_max_iter)
		out << "Iterações relaxação lagrangeana: " << s.lr_max_iter << "\n";
	if(s.method == "h" && s.h_max_iter)
		out << "Iterações Heurística: " << s.h_max_iter << "\n";
	return out;
}

Param::~Param(){
	result_file.close();
}