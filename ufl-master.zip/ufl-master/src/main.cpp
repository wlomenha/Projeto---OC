#include "../include/main.h"
#include "../include/instance.h"
#include "../include/bb.h"
#include "../include/cp.h"
#include "../include/lr.h"
#include "../include/heuristic.h"

ILOSTLBEGIN
namespace po = boost::program_options;
std::string config_file;
Param g_params;

namespace std{
	std::ostream& operator<<(std::ostream &os, const std::vector<std::string> &vec){    
		for (auto item : vec){ 
			os << item << " "; 
		} 
		return os; 
	}
}

void version(){
	std::cout << "Non Delayed Relax and Cut para o UFL.\n" <<
		"Versão 0.1 - Desenvolvido por: Victor Hugo e Amanda Azevedo (UFRJ-PESC-LABOTIM).\n";
}

Param load_params(int argc, char** argv){
	// Declare a group of options that will be 
	// allowed only on command line
	po::options_description generic("Opções Genéricas");
	generic.add_options()
    	("version,v", "Exibe a versão do programa.")
    	("help,h", "Exibe a mensagem de ajuda.")
    	("file,f", po::value<std::string>(&config_file),
                  "Caminho do arquivo de configuração que contém os parâmetros.")
    ;
    // Declare a group of options that will be 
	// allowed both on command line and in
	// config file
	po::options_description config("Configuração");
	config.add_options()
	    ("instance,i", po::value<std::string>()->default_value("instancias/dummy.txt"), 
	    	"Caminho da instância que será executada.")
	    ("EPS,e", po::value<double>()->default_value(0.0001),
	    	"Precisão numérica epsilon.")
	    ("debug,d", po::value<bool>()->default_value(false),
	    	"Modo debug")
	    ("method, m", po::value<std::string>()->default_value("bb"),
	    	"Algoritmo utilizado para resolução. lr|bb.")
	    ("output, o", po::value<std::string>()->default_value("result.txt"),
	    	"Caminho do arquivo de resultado que será criado.")
	    ("bb_cplex_buffs, c", po::value<bool>()->default_value(false),
	    	"Utilizar presolve, cortes e heurísticas do cplex.")
	    ("bb_node_limit, n", po::value<int>()->default_value(INT_MAX),
	    	"Limite de nós no branch and bound.")
	    ("time_limit, t", po::value<double>()->default_value(IloInfinity),
	    	"Limite de tempo para execução.")
	    ("show_solution, s", po::value<bool>()->default_value(false),
	    	"Imprime solução final na tela (A solução sempre é impressa no arquivo).")
	    ("lr_max_iter, i", po::value<int>()->default_value(300),
	    	"Máximo de iterações da Relaxação Lagrangeana.")
	    ("h_max_iter", po::value<int>()->default_value(300),
	    	"Máximo de iterações da heurística.")
	;

	po::options_description cmdline_options;
    cmdline_options.add(generic).add(config);

    po::options_description config_file_options;
	config_file_options.add(config);

	po::options_description visible("Opções Permitidas");
	visible.add(generic).add(config);

	po::variables_map vm;
    store(po::command_line_parser(argc, argv).
          options(cmdline_options).run(), vm);
    notify(vm);

	std::ifstream ifs(config_file.c_str());
    if (vm.count("file") && !ifs){
        std::cout << "Impossível abrir o arquivo: " << config_file << "\n";
        exit(1);
    }
    else if(vm.count("file") && ifs){
        store(parse_config_file(ifs, config_file_options), vm);
        notify(vm);
    }

    if (vm.count("help")) {
        std::cout << visible << "\n";
    }
    if (vm.count("version")) {
    	//TODO: ler versão do SVN?
        version();
    }

    return Param(vm);

}


int main(int argc, char* argv[]){
	g_params = load_params(argc,argv);
	Instance ins(g_params.instance);
	IloEnv env;

	if(g_params.method == "lr"){
		LR lr(ins);
		lr.solve();
		lr.print_solution();
	}else if(g_params.method == "bb"){
		BB bb(ins,env);
		bb.solve();
		bb.print_solution();
	}else if(g_params.method == "cp"){
		CP cp(ins,env);
		cp.solve();
	}

	return 0;
}