#include "../include/cp.h"


CP::CP(Instance& ins, IloEnv& env): ins(ins), env(env), cplex(env),
	model(env,"DUAL_CP"), u(env), primal(env), primal_y(env){
	x = new double*[ins.m];
	primal_x = new IloNumVar*[ins.m];
	y = new double[ins.m];
	for(int i = 0; i < ins.m; ++i){
		y[i] = 0;
		x[i] = new double[ins.n];
		primal_x[i] = new IloNumVar[ins.n];
		for(int j = 0; j < ins.n; ++j){
			x[i][j] = 0;
		}
	}
	load_model();
}


void CP::load_model(){
	std::stringstream name;
	double big_m = 10000;
	for(int j = 0; j < ins.n; ++j){
		name << "u_" << j;
		u.add(IloNumVar(env, -big_m,big_m, ILOFLOAT, name.str().c_str()));
		name.str("");
	}
	model.add(u);
	name << "v";
	v = IloNumVar(env,-big_m,big_m, ILOFLOAT, name.str().c_str());
	name.str("");
	model.add(v);

	model.add(IloMaximize(env, IloSum(u) + v));
	cplex.extract(model);
	cplex.setOut(env.getNullStream());
}

void CP::solve(){
	std::chrono::high_resolution_clock::time_point t0 = 
		std::chrono::high_resolution_clock::now();
	bool optimal = false;
	do{
		cplex.solve();
		std::cout << "Z = " << cplex.getObjValue() << "\n";
		std::cout << "U: ";
		for(int j = 0; j < ins.n; ++j){
			std::cout << cplex.getValue(u[j]) << " ";
		}
		std::cout << "\nV = " << cplex.getValue(v) << "\n";
		optimal = !sub_problem();
	}while(!optimal);
	std::chrono::high_resolution_clock::time_point dt = 
		std::chrono::high_resolution_clock::now();
	run_time = std::chrono::duration_cast<std::chrono::nanoseconds>
				(dt - t0).count() / pow(10,9);
	std::stringstream name;

	for(int i = 0; i < ins.m; ++i){
		name << "y_" << i;
		primal_y.add(IloNumVar(env,0,1, ILOFLOAT, name.str().c_str()));
		name.str("");
		for(int j = 0; j < ins.n; ++j){
			name << "x_" << i << "_" << j;
			primal_x[i][j] = IloNumVar(env,0,1,ILOFLOAT, name.str().c_str());
			primal.add(primal_x[i][j]);
			name.str("");
		}
	}

	primal.add(primal_y);

	IloExpr obj(env);
	for(int i = 0; i < ins.m; ++i){
		obj += ins.f[i]*primal_y[i];
	}

	for(int j = 0; j < ins.n; ++j){
		obj += cplex.getValue(u[j]);
	}

	for(int i = 0; i < ins.m; ++i){
		for(int j = 0; j < ins.n; ++j){
			obj += (ins.c[i][j] - cplex.getValue(u[j]))*primal_x[i][j];
		}
	}
	primal.add(IloMinimize(env,obj));
	obj.end();

	for(int i = 0; i < ins.m; ++i){
		for(int j = 0; j < ins.n; ++j){
			name << "couple_" << i << "_" << j;
			IloConstraint temp(primal_x[i][j] <= primal_y[i]);
			temp.setName(name.str().c_str());
			primal.add(temp);
			name.str("");
		}
	}
	cplex.extract(primal);
	cplex.exportModel("primal.lp");
	cplex.solve();
	std::cout << "LB = " << cplex.getObjValue() << "\n";
}


bool CP::sub_problem(){
	std::vector<std::pair<double, int>> C;

	for(int i = 0; i < ins.m; ++i){
		y[i] = 0;
		for(int j = 0; j < ins.n; ++j){
			x[i][j] = 0;
		}
	}

	std::vector<std::vector<int>> selected(ins.m, std::vector<int>());
	for(int i = 0; i < ins.m; ++i){
		std::vector<std::pair<double,int>> clients;
		for(int j = 0; j < ins.n; ++j){
			double u_j = cplex.getValue(u[j]);
			clients.push_back(std::make_pair(ins.c[i][j]-u_j,j));
		}
		std::sort(clients.begin(), clients.end());
		double sum = 0;
		int k = 0;
		while(k < clients.size() && clients[k].first < -g_params.EPS){
			sum += clients[k].first;
			selected[i].push_back(clients[k].second);
			k++;
		}
		C.push_back(std::make_pair(ins.f[i]+sum, i));
	}

	double f = 0;
	std::sort(C.begin(), C.end());


	std::cout << "C: ";
	for(int i = 0; i < C.size(); ++i){
		std::cout << C[i].second << " " << C[i].first << ": ";
		for(auto client: selected[i]){
			std::cout << client << " ";
		}
		std::cout << "\n";
	}
	std::cout << "\n";
	int k = 0;
	std::set<int> open;
	while(k < C.size() && C[k].first < -g_params.EPS){
		f += C[k].first;
		open.insert(C[k].second);
		k++;
	}

	for(auto i: open){
		y[i] = 1;
		for(auto j: selected[i]){
			x[i][j] = 1;
		}
	}

	std::cout << "F = " << f << "\n";
	double v_val = cplex.getValue(v);
	if(f < v_val){
		IloExpr exp(env);
		for(int i = 0; i < ins.m; ++i){
			for(int j = 0; j < ins.n; ++j){
				exp  += x[i][j]*(ins.c[i][j] - u[j]);
			}
		}

		for(int i = 0; i < ins.m; ++i){
			exp += y[i]*ins.f[i];
		}

		IloConstraint temp(v <= exp);
		model.add(temp);
		// cplex.exportModel("cp.lp");
		// std::cin.get();
		return true;
	}else{
		return false;
	}

}

CP::~CP(){
	for(int i = 0; i < ins.m; ++i){
		delete[] primal_x[i];
		delete[] x[i];
	}
	delete[] primal_x; delete[] x; delete[] y;

}