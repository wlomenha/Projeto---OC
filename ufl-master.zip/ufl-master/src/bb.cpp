#include "../include/bb.h"


BB::BB(const Instance& ins, IloEnv& env): ins(ins), env(env), cplex(env),
	model(env), z(IloInfinity), status(IloAlgorithm::Status::Unknown){

	fixed_x = new bool*[ins.m];
	x = new IloNumVar*[ins.m];
	for(int i = 0; i < ins.m; ++i){
		fixed_x[i] = new bool[ins.n];
		x[i] = new IloNumVar[ins.n];
	}
	fixed_y = new bool[ins.m];
	y = new IloNumVar[ins.m];	


	for(int i = 0; i < ins.m; ++i){
		fixed_y[i] = false;
		for(int j = 0; j < ins.n; ++j){
			fixed_x[i][j] = false;
		}
	}

	load_model();

	cplex.setParam(IloCplex::Param::Threads, 1);
	if(!g_params.bb_cplex_buffs){
		cplex.setParam(IloCplex::Param::Preprocessing::Presolve, CPX_OFF);
		// cplex.setParam(IloCplex::Param::Preprocessing::Relax, CPX_OFF);
		// cplex.setParam(IloCplex::Param::MIP::Strategy::PresolveNode, -1);
		cplex.setParam(IloCplex::Param::MIP::Strategy::HeuristicFreq, -1);
		cplex.setParam(IloCplex::Param::MIP::Strategy::RINSHeur, -1);
		cplex.setParam(IloCplex::Param::MIP::Strategy::FPHeur, -1);
		cplex.setParam(IloCplex::Param::MIP::Cuts::BQP, -1);
		cplex.setParam(IloCplex::Param::MIP::Cuts::Cliques, -1);
		cplex.setParam(IloCplex::Param::MIP::Cuts::Covers, -1);
		cplex.setParam(IloCplex::Param::MIP::Cuts::Disjunctive, -1);
		cplex.setParam(IloCplex::Param::MIP::Cuts::FlowCovers, -1);
		cplex.setParam(IloCplex::Param::MIP::Cuts::Gomory, -1);
		cplex.setParam(IloCplex::Param::MIP::Cuts::GUBCovers, -1);
		cplex.setParam(IloCplex::Param::MIP::Cuts::Implied, -1);
		cplex.setParam(IloCplex::Param::MIP::Cuts::LiftProj, -1);
		cplex.setParam(IloCplex::Param::MIP::Cuts::LocalImplied, -1);
		cplex.setParam(IloCplex::Param::MIP::Cuts::MCFCut, -1);
		cplex.setParam(IloCplex::Param::MIP::Cuts::MIRCut, -1);
		cplex.setParam(IloCplex::Param::MIP::Cuts::PathCut, -1);
		cplex.setParam(IloCplex::Param::MIP::Cuts::RLT, -1);
		cplex.setParam(IloCplex::Param::MIP::Cuts::ZeroHalfCut, -1);
	}

	if(g_params.time_limit < pow(10,5))
		cplex.setParam(IloCplex::Param::TimeLimit, g_params.time_limit);

	if(g_params.bb_node_limit < INT_MAX)
		cplex.setParam(IloCplex::Param::MIP::Limits::Nodes,g_params.bb_node_limit);

	if(!g_params.debug)
		cplex.setOut(env.getNullStream());


	if(g_params.debug && ins.m < 20){
		cplex.exportModel("ufl.lp");
	}

}


void BB::load_model(){
	std::stringstream name;

	for(int i = 0; i < ins.m; ++i){
		if(!fixed_y[i]){
			name << "y_" << i;
			y[i] = IloNumVar(env,0,1,ILOINT,name.str().c_str());
			model.add(y[i]);
			name.str("");
			for(int j = 0; j < ins.n; ++j){
				if(!fixed_x[i][j]){
					name << "x_" <<i << "_" <<j;
					x[i][j] = IloNumVar(env,0,1,ILOFLOAT, name.str().c_str());
					model.add(x[i][j]);
					name.str("");
				}
			}
		}
	}

	IloExpr obj(env);
	for(int i = 0; i < ins.m; ++i){
		if(!fixed_y[i])
			obj += ins.f[i]*y[i];
		for(int j = 0; j < ins.n; ++j){
			if(!fixed_x[i][j])
				obj += ins.c[i][j]*x[i][j];
		}
	}

	model.add(IloMinimize(env,obj));
	obj.end();


	for(int j = 0; j < ins.n; ++j){
		IloExpr exp(env);
		for(int i = 0; i < ins.m; ++i){
			if(!fixed_x[i][j])
				exp += x[i][j];
		}

		name << "demand_" << j;
		IloRange demand(exp == 1);
		demand.setName(name.str().c_str());
		model.add(demand);
 		name.str("");
 		exp.end();
	}

	for(int i = 0; i < ins.m; ++i){
	 	if(!fixed_y[i]){
		 	for(int j = 0; j < ins.n; ++j){
		 		if(!fixed_x[i][j]){
		 			name << "open_" << i << "_" << j;
		 			IloConstraint open(x[i][j] <= y[i]);
		 			open.setName(name.str().c_str());
		 			model.add(open);
		 			name.str("");
		 		}
		 	}
	 	}
	}
	cplex.extract(model);
}

void BB::solve(){
	std::chrono::high_resolution_clock::time_point t0 = 
		std::chrono::high_resolution_clock::now();
	try{
		cplex.solve();
	}catch(IloException& ex){
		std::cout << ex << "\n";
	}
	std::chrono::high_resolution_clock::time_point dt = 
		std::chrono::high_resolution_clock::now();
	run_time = std::chrono::duration_cast<std::chrono::nanoseconds>
				(dt - t0).count() / pow(10,9);

	status = cplex.getStatus();
	if(status != IloAlgorithm::Status::InfeasibleOrUnbounded){
		z = cplex.getBestObjValue();
	}else{
		std::cout << "ERRO: MODELO BRANCH AND BOUND INVIÁVEL ou ILIMITADO\n";
		exit(1);
	}
}

void BB::print_solution(){
	std::stringstream out, solution;

	if(g_params.bb_node_limit < INT_MAX)
		out << "Limite de nós:\t" << g_params.bb_node_limit << "\n";

	if(g_params.time_limit < IloInfinity)
		out << "Limite de tempo:\t" << g_params.time_limit << "\n";

	out << "Status: " << status << "\n";
	out << "Z: " << z << "\n";
	out << "Tempo(s): " << run_time << "\n";
	out << "Nós: " << cplex.getNnodes() << "\n";


	if(status == IloAlgorithm::Status::Optimal ||
		status == IloAlgorithm::Status::Feasible){	
		solution << "Solução:\n";
		for(int i = 0; i < ins.m; ++i){
			if(!fixed_y[i] && 1-cplex.getValue(y[i]) < g_params.EPS){
				solution << "\t" << i << ": ";
				for(int j = 0; j < ins.n; ++j){
					if(!fixed_x[i][j] && 1-cplex.getValue(x[i][j]) < g_params.EPS){
						solution << j << " ";
					}
				}
				solution << "\n";
			} 
		}
	}

	if(g_params.debug){
		std::cout << out.str();
		if(g_params.show_solution)
			std::cout << solution.str();
	}else{
		g_params.result_file << out.str() << solution.str();
	}
}

BB::~BB(){
	for(int i = 0; i < ins.m; ++i){
		delete[] fixed_x[i];
	}
	delete[] fixed_x; delete[] fixed_y;
	delete[] x; delete[] y;
}