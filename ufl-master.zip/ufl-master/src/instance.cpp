#include "../include/instance.h"


Instance::Instance(std::string path): path(path){
	std::ifstream arq(path, std::ios::in);
	if(!arq.good()){
		std::cout << "Can't open instance " << path << "\n";
		exit(1);
	}
	arq >> m;
	arq >> n;

	f = new int[m];
	c = new int*[m];
	for(int i = 0; i < m; ++i){
		arq >> f[i];
		c[i] = new int[n];
	}

	for(int i = 0; i < m; ++i){
		for(int j = 0; j < n; ++j){
			arq >> c[i][j];
		}
	}

	arq.close();

	if(g_params.debug && m < 20){
		std::cout << *this;
	}

}


std::ostream& operator<<(std::ostream& out, const Instance &ins){
	out << "Instance: " << ins.path << "\n";
	out << "m = " << ins.m << ", n = " << ins.n << "\n";
	out << "f: ";
	for(int i = 0; i < ins.m; ++i){
		out << ins.f[i] << " "; 
	}
	out << "\nc:\n";
	for(int i = 0; i < ins.m; ++i){
		for(int j = 0; j < ins.n; ++j){
			out << ins.c[i][j] << " ";
		}
		out << "\n";
	}

	return out;
}

Instance::~Instance(){
	for(int i = 0; i < m; ++i){
		delete[] c[i];
	}
	delete[] f; delete[] c;
}